using TMPro;
using UnityEngine;

public class HeroView : CombatCharacterView
{
    
}