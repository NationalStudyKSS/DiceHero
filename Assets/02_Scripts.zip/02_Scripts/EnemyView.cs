using UnityEngine;

public class EnemyView : CombatCharacterView
{
    
}