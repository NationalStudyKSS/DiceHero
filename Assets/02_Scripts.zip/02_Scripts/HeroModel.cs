﻿using System;
using UnityEngine;

/// <summary>
/// 영웅의 로직적인 처리를 담당하는 클래스
/// </summary>
public class HeroModel : CombatCharacterModel
{
    
}